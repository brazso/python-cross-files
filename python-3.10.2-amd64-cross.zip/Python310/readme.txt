After installed Python 3.10.2 Windows 64bit (python-3.10.2-amd64.exe) all files were removed except
+ include/
+ python310.dll
Then the following was removed
- include/internal/  
